"""Compatibility launcher; implementation belongs to the installed core."""
from _entry import run
if __name__ == "__main__":
    run("ljh_research.knowledge.append_rd_experience")
