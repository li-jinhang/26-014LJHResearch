"""Deprecated entry: initialization belongs to ljh-research-setup."""
from _entry import run
if __name__ == "__main__":
    import sys
    print("Initialization moved to ljh-research-setup; use setup.py plan/create/repair.", file=sys.stderr)
    run("ljh_research.setup.workspace")
