---
name: ljh-research
description: 'Compatibility entry for the former combined LJH Research skill. Resolve the workspace-selected ljh-research-manual or ljh-research-auto version; environment preparation and version changes use ljh-research-setup.'
---

# LJH Research：兼容入口

科研流程已拆分为两个独立 skill。本入口保留旧调用和脚本，不维护第三套科研模式规则。

1. 通过 `scripts/research.py workspace.get --project-root <project>` 读取 `research_version` 和 `skill_name`。已有任务则读 task.get 的冻结 research_version；旧任务缺失版本字段按 manual 处理。
2. manual 读取 [ljh-research-manual](../ljh-research-manual/SKILL.md)；auto 读取 [ljh-research-auto](../ljh-research-auto/SKILL.md)，按所选 skill 完成工作。
3. 未初始化、环境不可用或用户要求切换版本时，使用 [ljh-research-setup](../ljh-research-setup/SKILL.md)。切换仅影响新任务。

通用科学指南通过安装包的 `workflow.get` 获取，代码和模板由独立核心维护。旧 `references/` 路径保留迁移指引，旧 `scripts/` 只是公共安装包的兼容启动器。开发源位于 `D:/_Projects/26-014LjhResearch`。
