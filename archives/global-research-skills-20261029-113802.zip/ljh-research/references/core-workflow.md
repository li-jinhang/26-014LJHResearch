# 工作区准备

初始化、配置、修复和版本选择使用 [ljh-research-setup](../../ljh-research-setup/SKILL.md)。日常操作只读检查，不隐式初始化。
