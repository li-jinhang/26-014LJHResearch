# 版本入口

旧混合模式已拆分。通过 workspace.get 读取 setup 选择后，进入 [manual](../../ljh-research-manual/SKILL.md) 或 [auto](../../ljh-research-auto/SKILL.md)。manual 有界交付并严格结束，auto 使用证据与假设驱动的科研循环。
