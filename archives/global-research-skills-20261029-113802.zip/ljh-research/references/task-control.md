# 指南已迁入公共核心

通过 `scripts/research.py workflow.get --project-root <project> --params` 传入 `{"version":"manual","topic":"task-control"}` 获取唯一维护的指南；已有任务传 task_id 替代 version。auto 传 version=auto。科研入口见 [manual](../../ljh-research-manual/SKILL.md) 或 [auto](../../ljh-research-auto/SKILL.md)。
