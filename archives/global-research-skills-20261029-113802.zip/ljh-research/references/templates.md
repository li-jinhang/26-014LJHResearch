# 模板资源

模板唯一实现随 ljh-research-core 安装包发布，知识操作通过公共 knowledge.invoke 获取。技能目录不保留运行模板副本。
