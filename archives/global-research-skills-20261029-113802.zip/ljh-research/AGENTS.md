## Agent skills

### Issue tracker

Issues are tracked in GitHub Issues at `li-jinhang/ljh-research`. See `docs/agents/issue-tracker.md`.

### Triage labels

Uses the five default triage labels. See `docs/agents/triage-labels.md`.

### Domain docs

Uses the single-context layout. See `docs/agents/domain.md`.
