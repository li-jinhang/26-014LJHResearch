# LJH Research 领域词汇

领域词汇由配套程序项目维护，见 [CONTEXT.md](D:/_Projects/26-014LjhResearch/CONTEXT.md)。
