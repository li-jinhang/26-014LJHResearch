# 架构决策已迁至配套程序项目

见 [0002-separate-research-setup-skill](D:/_Projects/26-014LjhResearch/docs/adr/0002-separate-research-setup-skill.md)。
