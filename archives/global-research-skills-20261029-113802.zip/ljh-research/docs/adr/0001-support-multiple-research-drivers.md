# 架构决策已迁至配套程序项目

见 [0001-support-multiple-research-drivers](D:/_Projects/26-014LjhResearch/docs/adr/0001-support-multiple-research-drivers.md)。
