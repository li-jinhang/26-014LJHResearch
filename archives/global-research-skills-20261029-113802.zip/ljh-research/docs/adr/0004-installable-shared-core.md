# 架构决策已迁至配套程序项目

见 [0004-installable-shared-core](D:/_Projects/26-014LjhResearch/docs/adr/0004-installable-shared-core.md)。
