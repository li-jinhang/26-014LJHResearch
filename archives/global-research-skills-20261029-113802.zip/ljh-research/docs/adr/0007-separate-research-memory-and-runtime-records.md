# 架构决策已迁至配套程序项目

见 [0007-separate-research-memory-and-runtime-records](D:/_Projects/26-014LjhResearch/docs/adr/0007-separate-research-memory-and-runtime-records.md)。
