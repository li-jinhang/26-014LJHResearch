# 架构决策已迁至配套程序项目

见 [0006-execution-environment-plugins](D:/_Projects/26-014LjhResearch/docs/adr/0006-execution-environment-plugins.md)。
