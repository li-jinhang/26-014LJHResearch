# 架构决策已迁至配套程序项目

见 [0003-single-owner-per-research-task](D:/_Projects/26-014LjhResearch/docs/adr/0003-single-owner-per-research-task.md)。
