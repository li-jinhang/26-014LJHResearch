# 架构决策已迁至配套程序项目

见 [0008-deliver-replaceable-reference-controller](D:/_Projects/26-014LjhResearch/docs/adr/0008-deliver-replaceable-reference-controller.md)。
