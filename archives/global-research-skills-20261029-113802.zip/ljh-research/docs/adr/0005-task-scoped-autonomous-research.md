# 架构决策已迁至配套程序项目

见 [0005-task-scoped-autonomous-research](D:/_Projects/26-014LjhResearch/docs/adr/0005-task-scoped-autonomous-research.md)。
