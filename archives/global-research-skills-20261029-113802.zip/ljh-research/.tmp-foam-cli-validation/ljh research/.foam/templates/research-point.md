---
name: Research Point
description: Create a research-point card with the ljh research schema.
filepath: 2研究点/RP-\${FOAM_TITLE_SAFE}.md
---
---
id: RP-TODO
title: $FOAM_TITLE
type: research-point
status: 草案
priority: 中
created: $FOAM_DATE_FORMAT
updated: $FOAM_DATE_FORMAT
tags: []
---

# $FOAM_TITLE

## 研究问题与当前代码缺口

待补充。

## 核心假设

待补充。

## 证据

- 待补充可核验的代码、论文或实验记录。

## 关系

使用 \`supports: [[目标笔记#^evidence-id]]\`、\`contradicts:\` 或 \`tested_by:\` 声明科研语义边。
