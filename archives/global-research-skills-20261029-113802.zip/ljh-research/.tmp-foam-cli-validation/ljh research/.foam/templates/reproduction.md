---
name: Reproduction
description: Create a paper-reproduction card with the ljh research schema.
filepath: 4复现/REP-\${FOAM_TITLE_SAFE}.md
---
---
id: REP-TODO
title: $FOAM_TITLE
type: reproduction
status: 进行中
created: $FOAM_DATE_FORMAT
updated: $FOAM_DATE_FORMAT
tags: []
---

# $FOAM_TITLE

## 论文与来源

待补充。

## 对齐指标与论文值

待补充。

## 结论

待补充。
