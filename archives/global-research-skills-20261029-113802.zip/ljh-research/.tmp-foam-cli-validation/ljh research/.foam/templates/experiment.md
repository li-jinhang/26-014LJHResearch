---
name: Experiment
description: Create an executable experiment card with the ljh research schema.
filepath: 3实验/EXP-\${FOAM_TITLE_SAFE}.md
---
---
id: EXP-TODO
title: $FOAM_TITLE
type: experiment
status: 规划中
priority: 中
created: $FOAM_DATE_FORMAT
updated: $FOAM_DATE_FORMAT
tags: []
---

# $FOAM_TITLE

## 实验目的与研究问题

待补充。

## 数据与评估协议

待补充。

## 证据

- 待补充。

## 关系

使用 \`tested_by: [[2研究点/RP-...]]\` 或 \`supports: [[...#^evidence-id]]\` 声明关系。
